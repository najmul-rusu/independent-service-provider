import React from 'react';

const Blog = () => {
    return (
        <div>
            <h3>Blog</h3>
        </div>
    );
};

export default Blog;