import React from 'react';

const About = () => {
    return (
        <div>
            <h3>About</h3>
        </div>
    );
};

export default About;